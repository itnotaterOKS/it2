//oppg 2a
/* det er ikke nødvendig å løse oppgaven med script: man kan også i css ha kode som gjelder for #oppg2a:hover. Dette er kommentert ut i css-fila */
var tekstEl = document.querySelector("#oppg2a");
tekstEl.addEventListener("mouseover", endreStil);
tekstEl.addEventListener("mouseout", tilbakestill);
function endreStil(){
	tekstEl.style.backgroundColor="#89c9ca";
	tekstEl.style.fontSize="300%";
}
function tilbakestill(){
 	tekstEl.style.backgroundColor="white";
 	tekstEl.style.fontSize="200%";
}
/* funksjonenen kan enten endre stil direkte, slik som gjøres over, eller man kan legge til/fjerne en css-klasse */

//oppg 2b
var posEl = document.querySelector("#oppg2b");
var bodyEl = document.querySelector("body");
bodyEl.addEventListener("mousemove", skrivPos);
function skrivPos(e){
  var xPos = e.clientX;
  var yPos = e.clientY;
  posEl.innerHTML=xPos+", "+yPos;
}

//oppg 2c
var avstandEl = document.querySelector("#avstand");
var enhetEl = document.querySelector("#enhet");
var send2cEl = document.querySelector("#send2c");
var skrivAvstand = document.querySelector("#oppg2c");
send2cEl.addEventListener("click", beregn);
function beregn(){
  if(avstandEl.value<0){
    skrivAvstand.innerHTML="Du må skrive inn en positiv avstand!";
    skrivAvstand.style.color="red";
    skrivAvstand.style.fontSize="200%";
    return;
  }
  var beregnet=(avstandEl.value/enhet.value).toFixed(2);
  if(enhet.value=="1000"){
    skrivAvstand.innerHTML = "Avstanden "+avstandEl.value+" meter tilsvarer "+beregnet+" km";
  }
  else if(enhet.value=="1610"){
    skrivAvstand.innerHTML = "Avstanden "+avstandEl.value+" meter tilsvarer "+beregnet+" miles";
  }
  else{
    skrivAvstand.innerHTML = "Avstanden "+avstandEl.value+" meter tilsvarer "+beregnet+" yards";
  }
}

//oppg 2d
var xVerdiEl = document.querySelector("#xVerdi");
var yVerdiEl = document.querySelector("#yVerdi");
var send2dEl = document.querySelector("#send2d");
var tabellEl = document.querySelector("#gangetabell");
/* jeg lager option-elementene i scriptet for at det skal ta mindre tid enn å legge til 15 stykker i hver option. Det går også an å bruke inputelementer til hvert tall.*/
for(i=1; i<=15; i++){
  xVerdiEl.innerHTML+="<option value='"+i+"'>"+i+"</option>";
  yVerdiEl.innerHTML+="<option value='"+i+"'>"+i+"</option>";
}
send2dEl.addEventListener("click", lagTabell);
function lagTabell(){
  for(i=1; i<=yVerdiEl.value; i++){
    var rad = document.createElement("tr");
    for (j=1; j<=xVerdiEl.value; j++){
      var celle = document.createElement("td");
      celle.innerHTML =(i*j);
      rad.appendChild(celle);
    }
    tabellEl.appendChild(rad);
  }
}