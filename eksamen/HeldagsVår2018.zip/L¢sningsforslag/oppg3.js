/* kommentar: denne oppgaven kan løses på mange måter! det kreves bruk av noe datakolleksjoner for å få full
måloppnåelse, dette er kun et forslag på hvordan de kan brukes. Det går også an å legge til mer innhold i 
html filen i stedet for mye bruk av appendChild, men jeg synes mye appendChild er hensiktsmessig og tror
det er denne løsningen dere har bruk for å se.*/

//Henter inn elementer
var innhold = document.querySelector("#innhold");

//Oppretter knapper for å velge klassetrinn
var sporsmalEl = document.createElement("h1");
sporsmalEl.innerHTML="Hvilket trinn skal du registrere omtaler for?";
innhold.appendChild(sporsmalEl);
var knappVG1VG2 = document.createElement("button");
knappVG1VG2.id="venstre"
knappVG1VG2.innerHTML="VG1/VG2";
knappVG1VG2.addEventListener("click", VG1VG2);
innhold.appendChild(knappVG1VG2);
var knappVG3 = document.createElement("button");
knappVG3.id="hoyre"
knappVG3.innerHTML="VG3";
knappVG3.addEventListener("click", VG3);
innhold.appendChild(knappVG3);

// Oppretter løsning for å skrive omtaler for VG1 og VG2
var klasser1= ["1A", "1B", "1C", "1D", "1E", "1F"];
// Kan utvide med en tilsvarende array for VG2
// Funksjon for VG1 og VG2
function VG1VG2(){
	// Oppretter en div til å legge VG1 og VG2-valgene i
	var VG1VG2Div=document.createElement("div");
	var vg1vg2Sporsmal = document.createElement("h1");
	vg1vg2Sporsmal.innerHTML="Hvilken klasse vil du skrive omtale for?";
	VG1VG2Div.appendChild(vg1vg2Sporsmal);
	// Oppretter select for å velge aktuell klasse
	var velgKlasse = document.createElement("select");
	velgKlasse.id="velgKlasse"
	for(i=0; i<klasser1.length; i++){
		var valg = document.createElement("option");
		valg.setAttribute("value", klasser1[i]);
		valg.innerHTML=klasser1[i];
		velgKlasse.appendChild(valg);
	}
	VG1VG2Div.appendChild(velgKlasse);
	// Kan opprette tilsvarende for VG2 når koden skal utvides
	// Tekstboks til å legge inn omtalen
	var omtaleVG1VG2 = document.createElement("textarea");
	omtaleVG1VG2.id="omtaleVG1VG2";
	omtaleVG1VG2.setAttribute("placeholder", "Skriv inn omtale for klassen");
	VG1VG2Div.appendChild(omtaleVG1VG2);
	// Knapp til å sende omtalen
	var svarEl = document.createElement("button");
	svarEl.innerHTML="Send inn";
	svarEl.setAttribute("id", "svar1");
	svarEl.addEventListener("click", sendVG1VG2);
	VG1VG2Div.appendChild(svarEl);
	// Tømmer innholdsdiven
	innhold.innerHTML="";
	// Viser til løsningen for VG1 og VG2 i DOM
	innhold.appendChild(VG1VG2Div);
}

// Funksjon som sender omtalen
function sendVG1VG2(){
	// Henter inn elementer fra DOM
	var omtaleVG1VG2 = document.querySelector("#omtaleVG1VG2");
	var velgKlasse = document.querySelector("#velgKlasse");
	// Oppretter variabel til å lagre klassen og til å legge inn omtalen
	var klasse = ''
	var omtale = ''
	//Sjekker at omtalen ikke er tom
	if(omtaleVG1VG2.value==''){
		innhold.innerHTML="Du må skrive en omtale for klassen.";
		return;
	}
	else{
		klasse = velgKlasse.value;
		omtale = omtaleVG1VG2.value;
	}	
	// Skriver ut bekreftelse på at omtale er sendt
	var kvittering = document.createElement("div");
	kvittering.id="kvittering";
	var tekst=document.createElement("p");
	tekst.innerHTML="Følgende klasseomtale om klasse "+klasse+" er registrert: "+ omtale+". ";
	kvittering.appendChild(tekst);
	innhold.innerHTML = "";
	innhold.appendChild(kvittering);
	// Forslag til utvidelse her: legg inn knapp for å navigere tilbake til startmenyen:
	var menyKnapp = document.createElement("button");
	menyKnapp.innerHTML="Tilbake til startmenyen";
	menyKnapp.addEventListener("click",tilbake);
	innhold.appendChild(menyKnapp);
}

//Oppretter løsning for å skrive omtaler for elever i VG3
var klasser3 = ["3A","3B","3C","3D","3E","3F"];
function VG3(){
	// Oppretter en div til å legge VG3-valgene i
	var vg3Div=document.createElement("div");
	var vg3sporsmal = document.createElement("h1");
	vg3sporsmal.innerHTML="Hvilken klasse vil du skrive omtale for?";
	vg3Div.appendChild(vg3sporsmal);

	// Select til å velge aktuell klasse
	var velgKlasse = document.createElement("select");
	velgKlasse.id="selectVG3"
	velgKlasse.name="tredje";
	for(i=0; i<klasser3.length; i++){
		var valg = document.createElement("option");
		valg.setAttribute("value", klasser3[i]);
		valg.innerHTML=klasser3[i];
		velgKlasse.appendChild(valg);
	}
	vg3Div.appendChild(velgKlasse);
	var knapp3klasse = document.createElement("button");
	knapp3klasse.innerHTML = "skriv omtale";
	knapp3klasse.addEventListener("click", klasseValgVG3)
	vg3Div.appendChild(velgKlasse);
	vg3Div.appendChild(knapp3klasse);
	innhold.innerHTML="";
	innhold.appendChild(vg3Div);
}
//Implementerer løsning for 3A, 
//Array med elever, denne kan utvides til flere elever
var elever3A=["elev 1", "elev 2", "elev 3", "elev 4", "elev 5"];
function klasseValgVG3(){
	// Henter inn valgt klasse
	var klasse = document.querySelector("#selectVG3")
	if(klasse.value=="3A"){ 
		elever=elever3A;
	}
	else{
		innhold.innerHTML="<h1>Det er kun lagt inn løsning for 3A så langt</h1>";
	}
	// Bytter ut if-setningen med løsning for de andre klassene ved hjelp av en løkke når jeg skal utvide koden
	
	// Legger ut skjema for å skrive omtale om en elev i en ny div
	var klasseVG3 = document.createElement("div");
	klasseVG3.id="klasseVG3"
	var velgElev = document.createElement("h1");
	velgElev.innerHTML="Hvilken elev vil du skrive omtale for?";
	klasseVG3.appendChild(velgElev);
	
	var valgtElev = document.createElement("select");
	valgtElev.setAttribute("id", "elevVG3");
	for(i=0; i<elever.length; i++){
		var elev = document.createElement("option");
		elev.setAttribute("value", elever[i]);
		elev.innerHTML=elever[i];
		valgtElev.appendChild(elev);
	}
	klasseVG3.appendChild(valgtElev);
	var omtaleVG3 = document.createElement("textarea");
	omtaleVG3.id="omtaleVG3"
	omtaleVG3.setAttribute("placeholder", "Skriv inn omtale om eleven");
	klasseVG3.appendChild(omtaleVG3);
	var sendElev = document.createElement("button");
	sendElev.innerHTML="Send inn omtale";
	sendElev.setAttribute("id", "svar2");
	sendElev.addEventListener("click", sendVG3);
	klasseVG3.appendChild(sendElev);
	innhold.innerHTML = "";
	innhold.appendChild(klasseVG3)
}

function sendVG3(){
// Henter inn elementer fra DOM
	var omtaleVG3 = document.querySelector("#omtaleVG3");
	var elevVG3 = document.querySelector("#elevVG3")
	// Oppretter variabel til å lagre klassen og til å legge inn omtalen
	var elev = ''
	var omtale = ''
	// Sjekker at omtalen ikke er tom
	if(omtaleVG3.value==''){
		innhold.innerHTML="Du må skrive en omtale for eleven.";
		return;
	}
	else{
		elev= elevVG3.value;
		omtale = omtaleVG3.value;
	}	
	// Skriver ut bekreftelse på at omtale er sendt
	var kvittering = document.createElement("div");
	kvittering.id="kvittering";
	var tekst=document.createElement("p");
	tekst.innerHTML="Følgende elevomtale om elev "+elev+" er registrert: "+ omtale+". ";
	kvittering.appendChild(tekst);
	innhold.innerHTML=""
	innhold.appendChild(kvittering);
	// Forslag til utvidelse her: legg inn knapp for å navigere tilbake til startmenyen:
	var menyKnapp = document.createElement("button");
	menyKnapp.innerHTML="Tilbake til startmenyen";
	menyKnapp.addEventListener("click",tilbake);
	innhold.appendChild(menyKnapp);
}

function tilbake(){
	innhold.innerHTML="";
	innhold.appendChild(knappVG1VG2);
	innhold.appendChild(knappVG3);
}