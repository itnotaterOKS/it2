//Henter inn elementer og oppretter variabler
var canvasEl = document.querySelector('#canvas');
var ctx = canvasEl.getContext('2d');
var sporsmalEl = document.querySelector('#sporsmal');
var forrigeEl = document.querySelector('#forrige');
var nesteEl = document.querySelector('#neste');
forrigeEl.addEventListener('click', forrige);
nesteEl.addEventListener('click', neste);
// antall som har svart, kan også finnet separat for hvert spørsmål hvis vi ikke stoler på datagrunnlaget
var sum = 133; 

//Legger inn statistikk
var sporsmal = [
	{
		spm: 'Er du russ i år?',
		svar: [
			{alt: 'Ja', ant: 127},
			{alt: 'Nei', ant: 6}
		]
	}, {
		spm: 'Er du med i en russegruppe?',
		svar: [
			{alt: 'Ja', ant: 44},
			{alt: 'Nei', ant: 89}
		]
	}, {
		spm: 'Hva slags transportmiddel er du en del av?',
		svar: [
			{alt: 'Apostlenes hester', ant: 120},
			{alt: 'Buss', ant: 6},
			{alt: 'Van', ant: 0},
			{alt: 'Annet', ant: 7}
		]
	}, {
		spm: 'Hvor er russebuksa/dressen fra?',
		svar: [
			{alt: 'Russeservice', ant: 39},
			{alt: 'Russedress', ant: 64},
			{alt: 'Laget den selv', ant: 7},
			{alt: 'Annet', ant: 23}
		]
	}, {
		spm: 'Hvor mye har du brukt / kommer du til å bruke på RT?',
		svar: [
			{alt: 'ca 1000 kr', ant: 51},
			{alt: 'ca 2000 - 5000 kr', ant: 77},
			{alt: 'ca 10 000 kr', ant: 5}
		]
	}, {
		spm: 'ER DU GIRA?',
		svar: [
			{alt: 'JA', ant: 110},
			{alt: 'nei', ant: 23}
		]
	}
];

function tegnStatistikk() {
	//presenterer spørsmålet
	sporsmalEl.innerHTML = sporsmal[spmNr].spm; 

	//tømmer canvaset
	ctx.clearRect(0, 0, canvasEl.width, canvasEl.height);

	var vinkel = - Math.PI / 2;
	var hue = 0; //hsl-farger
	var teksthoyde = 32;
	ctx.font = teksthoyde+'px times';
	
	for (var i = 0; i < sporsmal[spmNr].svar.length; i++) {
		var alternativ = sporsmal[spmNr].svar[i];
		var vinkelAlt = alternativ.ant / sum * 2 * Math.PI;

		// tegner sirkelsektor
		ctx.beginPath();
		ctx.moveTo(200, 200);
		ctx.arc(200, 200, 150, vinkel, vinkel + vinkelAlt);
		ctx.closePath();
		ctx.fillStyle = 'hsl('+hue+', 100%, 50%)';
		ctx.fill();

		// presenterer fargekoding
		ctx.fillText(alternativ.alt, 400, 100 + teksthoyde * i);
		ctx.fill();

		vinkel += vinkelAlt;
		// endrer farge før neste alternativ
		hue += 70;
	}
}

var spmNr = 0;

//forrige og neste-knapper
function forrige() {
	if (spmNr - 1 >= 0) {
		spmNr -= 1;
		tegnStatistikk();
	}
}

function neste() {
	if (spmNr + 1 < sporsmal.length) {
		spmNr += 1;
		tegnStatistikk();
	}
}
tegnStatistikk();