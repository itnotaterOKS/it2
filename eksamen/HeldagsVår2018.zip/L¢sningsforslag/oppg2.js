var kvitteringEl = document.querySelector("#kvittering");
var navnEl = document.querySelector("#navn");
var epostEl = document.querySelector("#epost");
var antallEl = document.querySelector("#antall");
var innbundet = document.querySelector("#innbundet");
var heftet = document.querySelector("#heftet");
var sorthvitt = document.querySelector("#sorthvitt");
var farger = document.querySelector("#farger");
var knappEl = document.querySelector("#knapp");

knappEl.addEventListener("click", beregn);

function beregn(){
	// oppretter variabler for valgene man kan ta
	var prisBok=0;
	var totalPris=0;
	var type='';
	var farge='';
	// sjekker om korrekt antall er skrevet inn
	if(Number(antallEl.value)<1||Number(antallEl.value)>10){
		kvitteringEl.innerHTML="<h1>Du må kjøpe mellom 1 og 10 bøker!</h1>";
	}
	else if(navnEl.value==""||epostEl.value==""){
		kvitteringEl.innerHTML="<h1>Du må skrive inn både navn og epost!</h1>";
	}
	// skriver ellers ut kvittering
	else{	
		if(innbundet.checked==true){
			prisBok=200;
			type="innbundet";
		}
		else if(heftet.checked==true){
			prisBok=100;
			type="heftet";
		}
		if(sorthvitt.checked==true){
			prisBok+=0;
			farge="sort-hvitt";
		}
		else if(farger.checked==true){
			prisBok+=50;
			farge="farger";
		}
		totalPris=prisBok*(Number(antallEl.value));
				
		var overskrift = document.createElement("h1");
		overskrift.innerHTML="Kvittering for bestilt årbok";
		kvitteringEl.appendChild(overskrift);
		
		var tekst = document.createElement("p");
		tekst.innerHTML="Hei, "+navnEl.value+". Du har nå bestilt "+antallEl.value+" årbøker av typen "+type+" i "+farge+". Den totale prisen for årbøkene er "+totalPris+"kr. Kvitteringen sendes på epost til "+epostEl.value+"."; 
		kvitteringEl.appendChild(tekst);
		
	}
	
}